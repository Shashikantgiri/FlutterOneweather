import 'package:flutter/material.dart';
import 'package:oneweather/Worker/worker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Loading extends StatefulWidget {
  @override
  State<Loading> createState() => _LoadingState();
}

class _LoadingState extends State<Loading> {
  bool isloading = true;
  String temp = 's';
  String hum = 's';
  String air_speed = 's';
  String dec = 's';
  String main = 's';

  void startApp() async {
    worker instance = worker(location: "kharar");
    await instance.getData();

    temp = instance.temp;
    hum = instance.humidity;
    air_speed = instance.air_speed;
    dec = instance.description;
    main = instance.main;
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacementNamed(context, '/home', arguments: {
        "temp_value": temp,
        "hum_value": hum,
        "air_speed_value": air_speed,
        "dec_value": dec,
        "main_value": main
      });
    });
  }

  @override
  void initState() {
    //TODO implement initState
    startApp();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset("assets/images/Elogo.png"),
            SizedBox(
              height: 35,
            ),
            Text(
              "Oneweather",
              style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w400,
                  color: Colors.white),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "by shashi",
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w300,
                  color: Colors.white),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
                padding: EdgeInsets.only(
                  left: 20,
                  right: 20,
                ),
                width: MediaQuery.of(context).size.width,
                height: 60,
                child: ElevatedButton(
                    onPressed: () {},
                    child: isloading
                        ? CircularProgressIndicator(
                            color: Colors.black26,
                            backgroundColor: Colors.black26,
                          )
                        : Text('Loading'))),
            SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
      backgroundColor: Colors.blue[400],
    );
  }
}
