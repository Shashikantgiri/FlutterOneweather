import 'dart:math';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:oneweather/Worker/worker.dart';
import 'package:weather_icons/weather_icons.dart';
//import 'package:flutter_weather_icons/flutter_weather_icons.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController searchController = new TextEditingController();

  String temp = 'NA';
  String hum = 'NA';
  String air_speed = 'NA';
  String dec = 'NA';
  String main = 'NA';
  String search = 'NA';
  String city = "kharar";

  void startApp(String city) async {
    //write the city to see the weather
    worker instance = worker(location: city);
    await instance.getData();

    temp = instance.temp;
    hum = instance.humidity;
    air_speed = instance.air_speed;
    dec = instance.description;
    main = instance.main;
   // city=search;
    print(temp);
    // print(search);
  }

  @override
  initState() {
    super.initState();
   // startApp();
    print("This is a init state");
  }

  @override
  void setState(fn) {
    //TODO: implement setstate
    super.setState(fn);
    print("Set state is called");
  }

  @override
  void dispose() {
    //TODO: implement dispose
    super.dispose();
    print("Widget distroyed ");
  }

  @override
  Widget build(BuildContext context) {

    var city_name = [
      "Mumbai",
      "Delhi",
      "Indore",
      "Varanasi",
      "Allhabad",
      "Bhadohi"
    ];
    final _random = new Random();
    var cities = city_name[_random.nextInt(city_name.length)];

    String city=search;
    if(search?.isNotEmpty ?? false)
    {
      city =search;
    }
    startApp(city);

    return Scaffold(
      /* appBar: PreferredSize(
        preferredSize: Size.fromHeight(0),
        child: AppBar(
          backgroundColor: Colors.green,
        ),
      ), */
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  //stops is used to control the transition of graident
                  // stops: [
                  //  0.1,
                  // 0.7
                  //],
                  colors: [
                Colors.blueAccent,
                Colors.black12,
              ])),
          child: Column(
            children: [
              Container(
                //search container

                padding: EdgeInsets.symmetric(horizontal: 8),
                margin: EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(25)),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        // print(searchController.text);
                        search = searchController.text;
                        print(search);
                      },
                      child: Container(
                        child: Icon(
                          Icons.search,
                          color: Colors.blueAccent,
                        ),
                        margin: EdgeInsets.fromLTRB(3, 0, 8, 0),
                      ),
                    ),
                    Expanded(
                      child: TextField(
                        controller: searchController,
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Search City Example : $city"),
                      ),
                    )
                  ],
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: Colors.white.withOpacity(0.5)),
                        margin: EdgeInsets.symmetric(horizontal: 25),
                        padding: EdgeInsets.all(26),
                        child: Row(
                          children: [
                            // Image.network("fksd"),
                            Column(
                              children: [
                                Text(
                                  "$main",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "weather",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            )
                          ],
                        )),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 350,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: Colors.white.withOpacity(0.5),
                      ),
                      margin:
                          EdgeInsets.symmetric(horizontal: 25, vertical: 25),
                      padding: EdgeInsets.all(26),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(WeatherIcons.thermometer),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Expanded(
                                child: Text(
                                  "$temp",
                                  style: TextStyle(fontSize: 90),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Text(
                                "'C",
                                style: TextStyle(fontSize: 70),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.white.withOpacity(0.5)),
                      margin: EdgeInsets.fromLTRB(10, 0, 20, 0),
                      padding: EdgeInsets.all(26),
                      height: 220,
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Icon(WeatherIcons.day_windy),
                            ],
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Text(
                            "$air_speed",
                            style: TextStyle(
                                fontSize: 50, fontWeight: FontWeight.w400),
                          ),
                          Text("M/sec")
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.white.withOpacity(0.5)),
                      margin: EdgeInsets.fromLTRB(20, 0, 10, 0),
                      padding: EdgeInsets.all(26),
                      height: 220,
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Icon(WeatherIcons.humidity),
                            ],
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Text(
                            "$hum",
                            style: TextStyle(
                                fontSize: 50, fontWeight: FontWeight.w400),
                          ),
                          Text("Percent")
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.all(35),
                child: Column(
                  //  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text("Made by Shashi"),
                    Text("Data Provided By Openweathermap.org")
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
