import 'dart:convert';
import 'package:http/http.dart' as http;

class worker {
  String location = "s";

  //Constructor

  worker({this.location: "namethecity"});
/*  {
    location = this.location;
  }
*/

  String temp = "NA";
  String humidity = "NA";
  String air_speed = "NA";
  String description = "NA";
  String main = "NA";

  //method
  Future<void> getData() async {
    try {
      http.Response response;
      response = await http.get(Uri.parse(
          "https://api.openweathermap.org/data/2.5/weather?q=$location&appid=6bab5f18ddd645d2c84ef8197c3c2054"));
      Map data = jsonDecode(response.body);

      //Getting temperature and humidity
      Map temp_data = data['main'];
      String getHumidity = temp_data['humidity'].toString();
      double getTemp = temp_data['temp'] - 273.1;

      //Getting Air data
      Map wind = data['wind'];
      String getAir_speed = wind['speed'].toString();

      //Getting discribtion
      List weather_data = data['weather'];
      Map weather_main_data = weather_data[0];
      String getMain_des = weather_main_data['main'];
      String getDesc = weather_main_data['description'];

      //Assigning value
      temp = getTemp.toString();
      humidity = getHumidity;
      air_speed = getAir_speed;
      description = getDesc;
      main = getMain_des;
    } catch (e) {
      temp = "NA";
      humidity = "NA";
      air_speed = "NA";
      description = "NA";
      main = "NA";
    }
  }
}
