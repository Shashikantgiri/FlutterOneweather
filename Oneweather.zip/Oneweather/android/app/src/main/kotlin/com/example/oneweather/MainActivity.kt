package com.example.oneweather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
